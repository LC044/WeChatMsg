# -*- coding: utf-8 -*-
"""
@File    : __init__.py.py
@Author  : Shuaikang Zhou
@Time    : 2022/12/24 10:33
@IDE     : Pycharm
@Version : Python3.10
@comment : ···
"""
